package com.example.youtubesearchclient;

public class YoutubeVideos {
    public String videoId;
    public String title;
}
