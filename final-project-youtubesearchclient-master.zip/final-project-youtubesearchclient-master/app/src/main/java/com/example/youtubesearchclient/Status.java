package com.example.youtubesearchclient;

public enum Status {
    LOADING,
    ERROR,
    SUCCESS
}